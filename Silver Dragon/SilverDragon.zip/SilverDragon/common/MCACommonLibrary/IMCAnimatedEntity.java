package yourModPackage.common.MCACommonLibrary;

import yourModPackage.common.MCACommonLibrary.animation.AnimationHandler;

public interface IMCAnimatedEntity {
	public abstract AnimationHandler getAnimationHandler();
}
